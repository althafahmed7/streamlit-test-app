import streamlit as st

st.set_page_config(page_title="Streamlit Cloud Test")
st.title("✅ Streamlit is Working!")
st.write("If you can see this message, your app is live and rendering.")