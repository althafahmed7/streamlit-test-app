# Streamlit Cloud Test App

This is a minimal working Streamlit app. Use it to verify if Streamlit runs properly in a cloud environment.

## Instructions:
1. Upload this folder to a GitHub repo.
2. Go to https://share.streamlit.io
3. Click 'Deploy an app' → Select your repo → Set `app.py` as the entry point
4. Done! You’ll get a public link to access the app online.